---
name: Generated fetch typings
description: TypeScript library support required by the generated React API client.
---

The API client's generated header normalization uses `Headers.entries()`, which requires the `dom.iterable` TypeScript library.

**Why:** OpenAPI codegen can succeed even when the workspace's follow-up library typecheck fails because the API client TS config includes `dom` without iterable DOM declarations.

**How to apply:** Keep `dom.iterable` enabled in `lib/api-client-react/tsconfig.json` when changing TypeScript library targets or regenerating the client.
