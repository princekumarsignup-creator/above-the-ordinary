import { useState, type FormEvent } from 'react';
import { ArrowRight, ArrowUpRight, Check, Menu, X } from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useCreateReservation } from '@workspace/api-client-react';

type Product = {
  id: string;
  title: string;
  image: string;
  note: string;
};

const products: Product[] = [
  { id: '001', title: 'Signature Oversized Heavyweight Tee', image: '/tee-signature.jpg', note: 'The one that started it.' },
  { id: '002', title: 'Elite Monogram Acid Wash', image: '/tee-acid.jpg', note: 'No two washes are alike.' },
  { id: '003', title: 'Above Standard Box Tee', image: '/tee-box.jpg', note: 'A sharper kind of essential.' },
  { id: '004', title: 'After Hours Heavyweight Tee', image: '/tee-afterhours.jpg', note: 'Made for the hours after.' },
  { id: '005', title: 'Studio Edition 01 Tee', image: '/tee-studio.jpg', note: 'A study in restraint.' },
];
const sizes = ['S', 'M', 'L', 'XL'];
const whatsappMessage = encodeURIComponent('Hi, I am looking to inquire about the latest Above The Ordinary dropped collection.');
const queryClient = new QueryClient();

function Storefront() {
  const [activeProduct, setActiveProduct] = useState(products[0]);
  const [activeSize, setActiveSize] = useState('M');
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [country, setCountry] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formError, setFormError] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const reservation = useCreateReservation();

  const chooseProduct = (product: Product, shouldScroll = false) => {
    setActiveProduct(product);
    setActiveSize((current) => activeProduct.id === product.id ? current : 'M');
    setFormError('');
    if (shouldScroll) {
      window.setTimeout(() => document.getElementById('reserve')?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
  };

  const submitReservation = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError('');
    const details = `${activeProduct.id} // ${activeProduct.title} | Size ${activeSize} | Shipping destination: ${country.trim()}`;
    reservation.mutate(
      { data: { name: name.trim(), phone: contact.trim(), details } },
      {
        onSuccess: (receipt) => {
          if (receipt.status === 'success') {
            setConfirmation('Your request is in. You’re on the list.');
            setShowConfirmation(true);
          } else {
            setFormError('We couldn’t secure your request just yet. Please try again.');
          }
        },
        onError: (error) => {
          const message = error instanceof Error ? error.message : 'Something went wrong. Please try again.';
          setFormError(message || 'Something went wrong. Please try again.');
        },
      },
    );
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="noise min-h-[100dvh] overflow-hidden bg-[#0a0a0a] text-[#f2f2f0]">
      <div className="announcement">
        <span>PRIVATE RELEASE 01</span>
        <span className="announcement-copy">A limited allocation. By invitation and request.</span>
        <span>WORLDWIDE <span className="blue-dot" /></span>
      </div>

      <header className="site-header">
        <a href="#top" className="brand display" aria-label="Above The Ordinary home" data-testid="link-home">
          <span>ABOVE</span><span className="brand-small">THE</span><span>ORDINARY<span className="brand-period">.</span></span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#collection" data-testid="link-collection">Collection <span>01</span></a>
          <a href="#manifesto" data-testid="link-manifesto">Our point of view</a>
          <a href="#reserve" className="nav-reserve" data-testid="link-reservation">Request an allocation <ArrowUpRight size={14} /></a>
        </nav>
        <button className="mobile-menu-toggle" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} data-testid="button-mobile-menu">
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        {menuOpen && <nav className="mobile-menu" aria-label="Mobile navigation">
          <a href="#collection" onClick={closeMenu} data-testid="link-mobile-collection">Collection 01</a>
          <a href="#manifesto" onClick={closeMenu} data-testid="link-mobile-manifesto">Our point of view</a>
          <a href="#reserve" onClick={closeMenu} data-testid="link-mobile-reservation">Request an allocation <ArrowUpRight size={15} /></a>
        </nav>}
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow reveal"><span className="eyebrow-line" /> INDEPENDENT CREATIVE HOUSE <span className="eyebrow-index">EST. 2024 / INTL.</span></div>
          <h1 className="display reveal reveal-delay-1">ABOVE<br />THE <span className="hero-outline">ORDINARY</span><span className="hero-period">.</span></h1>
          <div className="hero-bottom reveal reveal-delay-2">
            <p>Elite Streetwear for the Unconventional.</p>
            <a href="#collection" className="explore-cta" data-testid="link-explore-collection">
              EXPLORE THE COLLECTION <ArrowRight size={15} />
            </a>
          </div>
          <div className="hero-meta reveal reveal-delay-3"><span>DROP 01 — FORM IN FREEDOM</span><span>01 / 05</span></div>
        </div>
        <div className="hero-visual">
          <img src="/tee-signature.jpg" alt="Sculptural heavyweight black tee in a dramatic studio" />
          <div className="hero-image-shade" />
          <div className="hero-image-caption"><span>THE EVERYDAY, RECONSIDERED</span><span>FIG. 001</span></div>
          <div className="hero-image-mark display">A<span>T</span>O</div>
          <span className="hero-vertical">OBJECTS FOR A DIFFERENT POINT OF VIEW</span>
        </div>
        <div className="hero-side-index display">A / 01</div>
      </section>

      <div className="ticker" aria-hidden="true">
        <div className="marquee-track">{Array.from({ length: 4 }, (_, i) => <span key={i}>ABOVE THE ORDINARY <i /> NOT MADE FOR EVERYONE <i /> ABOVE THE ORDINARY <i /> </span>)}</div>
      </div>

      <section className="manifesto section-wrap" id="manifesto">
        <div className="section-kicker"><span>01 — THE HOUSE</span><span>INDEPENDENT BY DESIGN</span></div>
        <div className="manifesto-content">
          <p className="manifesto-label">A NOTE ON BEING<br />ABOVE THE ORDINARY</p>
          <div>
            <h2 className="display">We don’t make<br />more of the same<span className="blue-period">.</span></h2>
            <p className="manifesto-body">We believe the ordinary is a space to move beyond, not fit into. Above The Ordinary is an independent creative house built around considered objects and uncommon perspective. We make fewer things, with more meaning — each piece an invitation to step outside the expected and move on your own terms.</p>
            <p className="manifesto-signoff">Less noise. More point of view.</p>
          </div>
        </div>
        <div className="manifesto-foot"><span>DESIGNED TO BE WORN INTO YOUR OWN STORY</span><span>NOT FOR THE MANY. FOR THE FEW WHO KNOW.</span></div>
      </section>

      <section className="collection section-wrap" id="collection">
        <div className="section-kicker"><span>02 — THE COLLECTION</span><span>DROP 01 / FIVE OBJECTS</span></div>
        <div className="collection-heading">
          <div><p className="mini-label">THE FIRST EDITION</p><h2 className="display">Pieces with<br />a point of view<span className="blue-period">.</span></h2></div>
          <div className="collection-intro"><span className="collection-count">05 <i> / 05</i></span><p>Five expressions of the same idea. Each made to become your own.</p></div>
        </div>
        <div className="product-grid">
          {products.map((product, index) => (
            <article className={`product-card ${index === 0 ? 'product-featured' : ''}`} key={product.id} data-testid={`card-product-${product.id}`}>
              <button className="product-image" type="button" onClick={() => chooseProduct(product)} aria-label={`Select ${product.title}`} data-testid={`button-select-product-${product.id}`}>
                <img className="image-motion" src={product.image} alt={product.title} />
                <span className="product-wash" />
                <span className="product-number display">{product.id}</span>
                <span className="product-image-arrow"><ArrowUpRight size={17} /></span>
                {index === 0 && <span className="edition-tag">THE ORIGINAL</span>}
              </button>
              <div className="product-info">
                <div className="product-title-row"><h3 data-testid={`text-product-title-${product.id}`}>{product.title}</h3><span data-testid={`text-product-price-${product.id}`}>$65.00</span></div>
                <p className="product-note">{product.note}</p>
                <div className="size-select-label"><span>SELECT SIZE</span><span>USD</span></div>
                <div className="size-matrix" role="group" aria-label={`Select size for ${product.title}`}>
                  {sizes.map((size) => (
                    <button
                      type="button"
                      key={size}
                      onClick={() => { setActiveProduct(product); setActiveSize(size); setFormError(''); }}
                      className={`size-button ${activeProduct.id === product.id && activeSize === size ? 'selected-size' : ''}`}
                      aria-pressed={activeProduct.id === product.id && activeSize === size}
                      data-testid={`button-size-${product.id}-${size}`}
                    >{size}</button>
                  ))}
                </div>
                <button className="reserve-piece" type="button" onClick={() => chooseProduct(product, true)} data-testid={`button-reserve-${product.id}`}>
                  <span>RESERVE PIECE</span><ArrowRight size={16} />
                </button>
              </div>
            </article>
          ))}
        </div>
        <p className="collection-note"><span className="blue-dot" /> EACH PIECE $65.00 USD <span className="collection-note-divider">/</span> AVAILABLE IN S — XL <span className="collection-note-divider">/</span> LIMITED ALLOCATION</p>
      </section>

      <section className="allocation" id="reserve">
        <div className="allocation-top section-wrap">
          <div className="section-kicker"><span>03 — PRIVATE ALLOCATION</span><span>REQUEST YOUR PIECE</span></div>
          <div className="allocation-grid">
            <div className="allocation-intro">
              <p className="mini-label">A PLACE IS NOT A PROMISE.</p>
              <h2 className="display">Make your<br />interest known<span className="blue-period">.</span></h2>
              <p className="allocation-description">Each release is intentionally limited. Leave your details and our allocation desk will follow up directly to confirm availability and next steps.</p>
              <div className="allocation-note"><span className="blue-dot" /> REQUESTS ARE REVIEWED PERSONALLY</div>
            </div>
            <div className="reservation-panel">
              {confirmation ? (
                <div className="success-state" role="status" data-testid="status-reservation-success">
                  <div className="success-icon"><Check size={22} /></div>
                  <p className="mini-label">REQUEST RECEIVED</p>
                  <h3 className="display">{confirmation}</h3>
                  <p>Our allocation desk will be in touch directly. Keep an eye on your messages.</p>
                  <span className="success-rule" />
                  <span className="success-reference">ABOVE THE ORDINARY / PRIVATE ALLOCATION</span>
                </div>
              ) : (
                <>
              <div className="form-heading"><div><span className="mini-label">ALLOCATION REQUEST</span><h3 className="display">Secure Allocation Reservation</h3></div><span className="form-asterisk">*</span></div>
                  <div className="selection-summary">
                    <div><span>YOUR SELECTION</span><strong data-testid="text-selected-piece">{activeProduct.id} // {activeProduct.title}</strong></div>
                    <span className="summary-size">SIZE {activeSize}</span>
                    <button type="button" onClick={() => document.getElementById('collection')?.scrollIntoView({ behavior: 'smooth' })} aria-label="Change selection" data-testid="button-change-selection"><ArrowUpRight size={15} /></button>
                  </div>
                  <form className="reservation-form" onSubmit={submitReservation}>
                    <label className="form-field"><span>FULL NAME <b>*</b></span><input type="text" autoComplete="name" required maxLength={120} value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" data-testid="input-name" /></label>
                    <label className="form-field"><span>INSTAGRAM OR PHONE <b>*</b></span><input type="text" autoComplete="tel" required maxLength={180} value={contact} onChange={(event) => setContact(event.target.value)} placeholder="@handle or +1 555 000 0000" data-testid="input-contact" /></label>
                    <label className="form-field"><span>SHIPPING DESTINATION <b>*</b></span>
                      <select autoComplete="country-name" required value={country} onChange={(event) => setCountry(event.target.value)} data-testid="input-country">
                        <option value="" disabled>Select destination</option>
                        <option value="United States">United States</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Canada">Canada</option>
                        <option value="India">India</option>
                        <option value="Australia">Australia</option>
                        <option value="France">France</option>
                        <option value="Germany">Germany</option>
                        <option value="Japan">Japan</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                      </select>
                    </label>
                    {formError && <p className="form-error" role="alert" data-testid="status-reservation-error">{formError}</p>}
                    <button type="submit" className="submit-reservation" disabled={reservation.isPending} data-testid="button-submit-reservation">
                      <span>{reservation.isPending ? 'SENDING REQUEST…' : 'SUBMIT ALLOCATION REQUEST'}</span>
                      {reservation.isPending ? <span className="button-loading" /> : <ArrowUpRight size={17} />}
                    </button>
                    <p className="form-privacy">Your details are shared only with our allocation desk.</p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="footer-top">
          <a href="#top" className="brand footer-brand display" data-testid="link-footer-home"><span>ABOVE</span><span className="brand-small">THE</span><span>ORDINARY<span className="brand-period">.</span></span></a>
          <p>Objects for a different<br />point of view.</p>
          <a href="#top" className="back-top" data-testid="link-back-to-top">BACK TO THE TOP <ArrowUpRight size={15} /></a>
        </div>
        <div className="footer-bottom"><span>© 2025 ABOVE THE ORDINARY</span><span>INDEPENDENT CREATIVE HOUSE / INTERNATIONAL</span><a href={`https://wa.me/?text=${whatsappMessage}`} target="_blank" rel="noreferrer">DIRECT INQUIRIES <ArrowUpRight size={12} /></a></div>
      </footer>

      {showConfirmation && (
        <div
          className="success-overlay"
          role="presentation"
          onClick={(event) => {
            if (event.target === event.currentTarget) setShowConfirmation(false);
          }}
          data-testid="overlay-reservation-success"
        >
          <section className="success-dialog" role="dialog" aria-modal="true" aria-labelledby="success-title">
            <button type="button" className="success-dismiss" onClick={() => setShowConfirmation(false)} aria-label="Close confirmation" data-testid="button-dismiss-confirmation">
              <X size={18} />
            </button>
            <div className="success-icon"><Check size={22} /></div>
            <p className="mini-label">SECURE ALLOCATION RESERVATION</p>
            <h2 id="success-title" className="display">Allocation received.</h2>
            <p className="success-dialog-copy" data-testid="text-reservation-confirmation">Order Received. Our distribution desk will contact you via WhatsApp / DM shortly to finalize your allocation footprint.</p>
            <button type="button" className="success-continue" onClick={() => setShowConfirmation(false)} data-testid="button-continue-shopping">
              CONTINUE TO THE COLLECTION <ArrowRight size={15} />
            </button>
          </section>
        </div>
      )}

      <a className="whatsapp-cta" href={`https://wa.me/?text=${whatsappMessage}`} target="_blank" rel="noreferrer" aria-label="Message Above The Ordinary on WhatsApp" data-testid="link-whatsapp">
        <span className="whatsapp-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M20.05 11.75a8.06 8.06 0 0 1-11.94 7.03L4 20l1.28-3.94A8.05 8.05 0 1 1 20.05 11.75Z" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M9 8.2c.25-.55.46-.57.73-.58h.62c.2 0 .43.06.56.42l.73 1.76c.1.24.08.43-.08.62l-.56.67c-.16.18-.33.36-.14.68.19.33.84 1.38 1.83 2.23 1.25 1.08 2.3 1.42 2.63 1.57.32.16.51.13.7-.08.19-.2.8-.93 1.01-1.25.21-.31.43-.26.72-.16l1.7.8c.34.16.57.24.66.37.08.14.08.78-.2 1.53-.29.75-1.65 1.47-2.26 1.55-.58.07-1.31.1-2.12-.15-.49-.16-1.12-.36-1.93-.72-3.39-1.47-5.6-4.9-5.77-5.13-.17-.23-1.37-1.82-1.37-3.47 0-1.64.86-2.45 1.16-2.79Z" fill="currentColor" transform="translate(-1.4 -1.3) scale(.91)"/></svg></span>
        <span className="whatsapp-label">WHATSAPP <i>—</i> LET’S TALK</span><ArrowUpRight size={15} />
      </a>
    </main>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Storefront />
    </QueryClientProvider>
  );
}

export default App;
