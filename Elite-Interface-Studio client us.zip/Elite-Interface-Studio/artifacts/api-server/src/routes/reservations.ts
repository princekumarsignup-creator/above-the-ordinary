import { Router, type IRouter } from "express";
import {
  CreateReservationBody,
  CreateReservationResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const allocationWebhookUrl =
  "https://script.google.com/macros/s/AKfycbzwtkAoe7CNkWV9APLFigkpDPg8Qm4iIlLKHeF7EKgWLUe13jwcbb2UiaH7jn02Mz69/exec";

router.post("/reservations", async (req, res): Promise<void> => {
  const parsed = CreateReservationBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn("Rejected invalid reservation submission");
    res.status(400).json({ error: "Check the reservation details and try again." });
    return;
  }

  try {
    const webhookResponse = await fetch(allocationWebhookUrl, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(parsed.data),
      signal: AbortSignal.timeout(15_000),
    });

    const result: unknown = await webhookResponse.json().catch(() => null);
    if (
      !webhookResponse.ok ||
      !result ||
      typeof result !== "object" ||
      !("status" in result) ||
      result.status !== "success"
    ) {
      req.log.warn(
        { webhookStatus: webhookResponse.status },
        "Allocation desk did not accept the reservation",
      );
      res.status(502).json({
        error: "We could not confirm this allocation. Please try again or contact the distribution desk.",
      });
      return;
    }

    const resultMessage =
      "message" in result && typeof result.message === "string"
        ? result.message
        : "Reservation received.";
    res.json(
      CreateReservationResponse.parse({
        status: "success",
        message: resultMessage,
      }),
    );
  } catch (error) {
    req.log.warn({ err: error }, "Reservation webhook request failed");
    res.status(502).json({
      error: "The distribution desk is temporarily unavailable. Please try again shortly.",
    });
  }
});

export default router;
